@echo off
chcp 65001 >nul
title Anka Security - EXE Olusturucu
cd /d "%~dp0"
set PY=
py -3 --version >nul 2>&1 && set PY=py -3
if not defined PY (
  python --version >nul 2>&1 && set PY=python
)
if not defined PY (
  echo [HATA] Python bulunamadi.
  echo Python'u yeniden kurun ve "Add python.exe to PATH" ile "py launcher" kutularini isaretleyin.
  pause
  exit /b 1
)
echo Kullanilan Python: %PY%
%PY% --version
%PY% -m pip install --upgrade pip customtkinter pyinstaller
if errorlevel 1 (
  echo [HATA] Paket kurulumu basarisiz. Internet baglantinizi kontrol edin.
  pause
  exit /b 1
)
%PY% -m PyInstaller --noconfirm --clean --onefile --windowed --name AnkaSecurity --collect-all customtkinter anka_security.py
if errorlevel 1 (
  echo [HATA] Olusturma basarisiz oldu. Python 3.14 yeni oldugu icin sorun cikarsa Python 3.12 veya 3.13 kurup tekrar deneyin.
  pause
  exit /b 1
)
copy /Y dist\AnkaSecurity.exe AnkaSecurity.exe >nul
echo.
echo TAMAM! AnkaSecurity.exe bu klasorde olusturuldu.
pause
