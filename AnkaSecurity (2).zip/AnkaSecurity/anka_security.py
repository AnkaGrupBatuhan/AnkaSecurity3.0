# -*- coding: utf-8 -*-
"""
Anka Security - Yerel Tarama ve Karantina Uygulaması (Simüle İmza Motoru)

Gereksinimler:  pip install customtkinter
Not: Bu uygulama gerçek bir antivirüs motoru İÇERMEZ. Tespit mantığı;
dosya/klasör adı kuralları, şüpheli uzantılar, bilinen test hash'leri ve
test amaçlı içerik imzasına dayanan SİMÜLE bir mekanizmadır.
"""

import os
import re
import sys
import queue
import shutil
import sqlite3
import hashlib
import zipfile
import tempfile
import ctypes
import threading
from contextlib import closing
from datetime import datetime
from pathlib import Path

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import customtkinter as ctk

APP_NAME = "Anka Security"
DATE_FMT = "%d.%m.%Y %H:%M:%S"


# ----------------------------------------------------------------------------
# Yardımcı fonksiyonlar
# ----------------------------------------------------------------------------
def norm(p):
    return os.path.normcase(os.path.abspath(p))


def is_inside(child, parent):
    c, p = norm(child), norm(parent)
    return c == p or c.startswith(p.rstrip(os.sep) + os.sep)


def get_base_dir():
    """PyInstaller --onefile ile çalışırken .exe'nin bulunduğu klasörü döndürür."""
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


def hide_path(path):
    """Windows'ta klasörü gizli yapar (başka sistemlerde sessizce geçer)."""
    try:
        if os.name == "nt":
            ctypes.windll.kernel32.SetFileAttributesW(str(path), 0x02)  # HIDDEN
    except Exception:
        pass


def prepare_quarantine_dir():
    """
    Karantina klasörünü uygulamanın çalıştığı dizinde oluşturur.
    Yazma izni yoksa LOCALAPPDATA altına düşer.
    (İsterseniz ilk adaya r"C:\\Karantina_Deposu" yazabilirsiniz.)
    """
    candidates = [
        os.path.join(get_base_dir(), "Karantina_Deposu"),
        os.path.join(os.environ.get("LOCALAPPDATA", str(Path.home())),
                     "AnkaSecurity", "Karantina_Deposu"),
    ]
    for c in candidates:
        try:
            os.makedirs(c, exist_ok=True)
            probe = os.path.join(c, ".yazma_testi")
            with open(probe, "w") as f:
                f.write("ok")
            os.remove(probe)
            hide_path(c)
            return c
        except OSError:
            continue
    raise RuntimeError("Karantina klasörü oluşturulamadı.")


QUARANTINE_DIR = prepare_quarantine_dir()
DB_PATH = os.path.join(QUARANTINE_DIR, "karantina.db")


# ----------------------------------------------------------------------------
# Veritabanı (SQLite) - her iş parçacığı kendi bağlantısını açar
# ----------------------------------------------------------------------------
def db_connect():
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    return conn


def db_init():
    with closing(db_connect()) as conn, conn:
        conn.execute(
            """CREATE TABLE IF NOT EXISTS quarantine (
                   id INTEGER PRIMARY KEY AUTOINCREMENT,
                   original_name TEXT NOT NULL,
                   original_path TEXT NOT NULL,
                   quarantine_name TEXT NOT NULL,
                   quarantine_date TEXT NOT NULL,
                   threat TEXT,
                   is_dir INTEGER NOT NULL DEFAULT 0
               )"""
        )


def db_add(original_name, original_path, quarantine_name, date, threat, is_dir):
    with closing(db_connect()) as conn, conn:
        conn.execute(
            "INSERT INTO quarantine (original_name, original_path, quarantine_name,"
            " quarantine_date, threat, is_dir) VALUES (?,?,?,?,?,?)",
            (original_name, original_path, quarantine_name, date, threat, int(is_dir)),
        )


def db_list():
    with closing(db_connect()) as conn:
        return conn.execute("SELECT * FROM quarantine ORDER BY id DESC").fetchall()


def db_get(rec_id):
    with closing(db_connect()) as conn:
        return conn.execute("SELECT * FROM quarantine WHERE id=?", (rec_id,)).fetchone()


def db_delete(rec_id):
    with closing(db_connect()) as conn, conn:
        conn.execute("DELETE FROM quarantine WHERE id=?", (rec_id,))


# ----------------------------------------------------------------------------
# Simüle edilmiş tespit motoru
# ----------------------------------------------------------------------------
NAME_KEYWORDS = ("malware", "trojan", "virus", "ransom", "keylogger", "backdoor", "rootkit")
SUSPICIOUS_EXTENSIONS = {".infected", ".malware", ".virus", ".vir", ".trojan"}
DOUBLE_EXT_RE = re.compile(
    r"\.(pdf|docx?|xlsx?|jpe?g|png|txt|mp3|mp4)\.(exe|scr|bat|cmd|vbs|js|jar|com|pif)$", re.I
)
# Bilinen MD5 imzaları (örnek havuz). Buraya kendi test hash'lerinizi ekleyebilirsiniz.
SIGNATURE_HASHES = {
    "44d88612fea8a8f36de82e1278abb02f": "EICAR-Test-File",
    "d41d8cd98f00b204e9800998ecf8427e_": "Ornek-Imza (devre disi)",
}
# Test amaçlı içerik imzası (kaynak kodda birleşik durmaması için bölünmüştür)
CONTENT_MARKERS = (b"ANKA-TEST-" + b"VIRUS-SIGNATURE",)
MAX_HASH_SIZE = 100 * 1024 * 1024  # 100 MB üstü dosyalarda içerik taraması atlanır


def check_name(name):
    low = name.lower().replace("antivirus", "").replace("anti-virus", "")
    for kw in NAME_KEYWORDS:
        if kw in low:
            return f"Şüpheli ad ('{kw}')"
    ext = os.path.splitext(low)[1]
    if ext in SUSPICIOUS_EXTENSIONS:
        return f"Şüpheli uzantı ({ext})"
    if DOUBLE_EXT_RE.search(low):
        return "Çift uzantı hilesi"
    return None


def analyze(path, is_dir):
    """Tehdit varsa açıklama metnini, yoksa None döndürür."""
    name = os.path.basename(path)
    result = check_name(name)
    if result:
        return result
    if is_dir:
        return None

    ext = os.path.splitext(name)[1].lower()

    # ZIP arşivi: içindeki dosya adlarını kontrol et
    if ext == ".zip":
        try:
            with zipfile.ZipFile(path) as z:
                for entry in z.namelist():
                    inner = os.path.basename(entry.rstrip("/"))
                    r = check_name(inner)
                    if r:
                        return f"ZIP içeriği: {inner} → {r}"
        except (zipfile.BadZipFile, OSError, RuntimeError, NotImplementedError):
            pass
    # RAR arşivi: yalnızca ad/uzantı kontrolü yukarıda yapıldı (harici kütüphane gerekmez)

    # Hash ve içerik imzası
    try:
        if os.path.getsize(path) > MAX_HASH_SIZE:
            return None
        h = hashlib.md5()
        tail = b""
        with open(path, "rb") as f:
            while True:
                chunk = f.read(1 << 20)
                if not chunk:
                    break
                h.update(chunk)
                buf = tail + chunk
                for m in CONTENT_MARKERS:
                    if m in buf:
                        return "İmza eşleşmesi (içerik)"
                tail = buf[-64:]
        digest = h.hexdigest()
        if digest in SIGNATURE_HASHES:
            return f"Hash eşleşmesi ({SIGNATURE_HASHES[digest]})"
    except (OSError, PermissionError):
        return None
    return None


# ----------------------------------------------------------------------------
# Karantina işlemleri
# ----------------------------------------------------------------------------
def unique_path(directory, filename):
    candidate = os.path.join(directory, filename)
    counter = 1
    base, ext = os.path.splitext(filename)
    while os.path.lexists(candidate):
        candidate = os.path.join(directory, f"{base}_{counter}{ext}")
        counter += 1
    return candidate


def quarantine_item(path, is_dir, threat):
    """Öğeyi orijinal konumundan keser, karantinaya taşır, kaydı veritabanına yazar."""
    original_name = os.path.basename(path)
    now = datetime.now()
    q_filename = f"{original_name}_{now.strftime('%Y%m%d_%H%M%S')}.safe"
    dest = unique_path(QUARANTINE_DIR, q_filename)
    shutil.move(path, dest)
    try:
        db_add(original_name, os.path.abspath(path), os.path.basename(dest),
               now.strftime(DATE_FMT), threat, is_dir)
    except Exception:
        shutil.move(dest, path)  # kayıt yazılamazsa geri al
        raise


def default_scan_roots():
    home = Path.home()
    cands = [home / "Downloads", home / "Desktop", home / "Documents",
             Path(tempfile.gettempdir())]
    appdata = os.environ.get("APPDATA")
    if appdata:
        cands.append(Path(appdata) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup")
    seen, roots = set(), []
    for p in cands:
        if p.exists() and norm(str(p)) not in seen:
            seen.add(norm(str(p)))
            roots.append(str(p))
    return roots


def protected_dirs():
    vals = [os.environ.get(k) for k in ("SystemRoot", "ProgramFiles", "ProgramFiles(x86)")]
    return {norm(v) for v in vals if v}


SKIP_DIR_NAMES = {"$recycle.bin", "system volume information"}


# ----------------------------------------------------------------------------
# Arayüz
# ----------------------------------------------------------------------------
class AnkaSecurityApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")

        self.title(APP_NAME)
        self.geometry("1020x700")
        self.minsize(860, 560)

        self.msg_q = queue.Queue()
        self.stop_event = threading.Event()
        self.scanning = False
        self.scanned_count = 0
        self.found_count = 0

        self._build_ui()
        self._style_treeview()
        self.refresh_quarantine()
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self.after(80, self._process_queue)

    # ---------------------------- UI kurulumu ----------------------------
    def _build_ui(self):
        header = ctk.CTkLabel(self, text="🛡  Anka Security",
                              font=ctk.CTkFont(size=24, weight="bold"))
        header.pack(anchor="w", padx=20, pady=(14, 4))

        self.tabs = ctk.CTkTabview(self, command=self._on_tab_change)
        self.tabs.pack(fill="both", expand=True, padx=16, pady=(0, 14))
        self.tab_scan = self.tabs.add("Tarama Ekranı")
        self.tab_quar = self.tabs.add("Karantina Bölümü")

        self._build_scan_tab()
        self._build_quarantine_tab()

    def _build_scan_tab(self):
        t = self.tab_scan
        bar = ctk.CTkFrame(t, fg_color="transparent")
        bar.pack(fill="x", pady=(6, 8))

        self.btn_scan = ctk.CTkButton(bar, text="Otomatik Tara", width=160, height=38,
                                      command=self.start_auto_scan)
        self.btn_scan.pack(side="left", padx=(0, 8))

        self.btn_folder = ctk.CTkButton(bar, text="Klasör Seç ve Tara", width=170, height=38,
                                        fg_color="#3b5b7a", hover_color="#2f4a63",
                                        command=self.start_folder_scan)
        self.btn_folder.pack(side="left", padx=(0, 8))

        self.btn_stop = ctk.CTkButton(bar, text="Durdur", width=100, height=38,
                                      fg_color="#a33a3a", hover_color="#802d2d",
                                      state="disabled", command=self.stop_scan)
        self.btn_stop.pack(side="left")

        self.lbl_status = ctk.CTkLabel(t, text="Hazır.", anchor="w")
        self.lbl_status.pack(fill="x", padx=4)

        prog = ctk.CTkFrame(t, fg_color="transparent")
        prog.pack(fill="x", pady=(4, 2))
        self.progress = ctk.CTkProgressBar(prog, height=16)
        self.progress.set(0)
        self.progress.pack(side="left", fill="x", expand=True, padx=(4, 10))
        self.lbl_percent = ctk.CTkLabel(prog, text="%0", width=50)
        self.lbl_percent.pack(side="right")

        stats = ctk.CTkFrame(t, fg_color="transparent")
        stats.pack(fill="x", pady=(2, 6))
        self.lbl_scanned = ctk.CTkLabel(stats, text="Taranan: 0")
        self.lbl_scanned.pack(side="left", padx=(4, 20))
        self.lbl_found = ctk.CTkLabel(stats, text="Tespit edilen: 0", text_color="#ff6b6b")
        self.lbl_found.pack(side="left")

        self.log_box = ctk.CTkTextbox(t, wrap="none", font=ctk.CTkFont(family="Consolas", size=12))
        self.log_box.pack(fill="both", expand=True, padx=2, pady=(0, 2))
        try:
            self.log_box.tag_config("threat", foreground="#ff6b6b")
            self.log_box.tag_config("info", foreground="#6cb2ff")
            self.log_box.tag_config("ok", foreground="#9aa0a6")
            self.log_box.tag_config("good", foreground="#5fd38d")
        except Exception:
            pass
        self.log_box.configure(state="disabled")

    def _build_quarantine_tab(self):
        t = self.tab_quar
        top = ctk.CTkFrame(t, fg_color="transparent")
        top.pack(fill="x", pady=(6, 8))
        ctk.CTkButton(top, text="Yenile", width=100, command=self.refresh_quarantine).pack(side="left")
        self.lbl_qinfo = ctk.CTkLabel(top, text="", anchor="w")
        self.lbl_qinfo.pack(side="left", padx=14)

        wrap = ctk.CTkFrame(t)
        wrap.pack(fill="both", expand=True)

        cols = ("name", "path", "threat", "date", "type")
        self.tree = ttk.Treeview(wrap, columns=cols, show="headings", selectmode="browse")
        headings = {"name": ("Orijinal Ad", 190), "path": ("Orijinal Konum", 330),
                    "threat": ("Tespit", 200), "date": ("Karantina Tarihi", 140),
                    "type": ("Tür", 70)}
        for c in cols:
            self.tree.heading(c, text=headings[c][0])
            self.tree.column(c, width=headings[c][1], anchor="w")
        vsb = ttk.Scrollbar(wrap, orient="vertical", command=self.tree.yview)
        hsb = ttk.Scrollbar(wrap, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")
        wrap.grid_rowconfigure(0, weight=1)
        wrap.grid_columnconfigure(0, weight=1)

        # Sağ tık menüsü
        self.menu = tk.Menu(self, tearoff=0, bg="#2b2b2b", fg="white",
                            activebackground="#1f6aa5", activeforeground="white", bd=0)
        self.menu.add_command(label="Geri Yükle", command=self.restore_selected)
        self.menu.add_separator()
        self.menu.add_command(label="Kalıcı Olarak Sil", command=self.delete_selected)
        self.tree.bind("<Button-3>", self._show_context_menu)

        ctk.CTkLabel(t, text="İpucu: Bir öğeye sağ tıklayarak \"Geri Yükle\" seçeneğini kullanabilirsiniz.",
                     text_color="#9aa0a6").pack(anchor="w", pady=(6, 0))

    def _style_treeview(self):
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("Treeview", background="#242424", foreground="#e6e6e6",
                        fieldbackground="#242424", rowheight=28, borderwidth=0)
        style.configure("Treeview.Heading", background="#333333", foreground="white",
                        relief="flat", font=("Segoe UI", 10, "bold"))
        style.map("Treeview", background=[("selected", "#1f6aa5")])
        style.map("Treeview.Heading", background=[("active", "#444444")])

    # ---------------------------- Günlük (log) ----------------------------
    def _log_lines(self, items):
        if not items:
            return
        self.log_box.configure(state="normal")
        for text, tag in items:
            try:
                self.log_box.insert("end", text + "\n", tag)
            except Exception:
                self.log_box.insert("end", text + "\n")
        try:
            if int(self.log_box.index("end-1c").split(".")[0]) > 5000:
                self.log_box.delete("1.0", "1000.0")
        except Exception:
            pass
        self.log_box.see("end")
        self.log_box.configure(state="disabled")

    def _clear_log(self):
        self.log_box.configure(state="normal")
        self.log_box.delete("1.0", "end")
        self.log_box.configure(state="disabled")

    # ---------------------------- Tarama kontrol ----------------------------
    def start_auto_scan(self):
        roots = default_scan_roots()
        if not roots:
            messagebox.showwarning(APP_NAME, "Taranacak varsayılan klasör bulunamadı.")
            return
        self._start_scan(roots)

    def start_folder_scan(self):
        folder = filedialog.askdirectory(title="Taranacak ana klasörü seçin")
        if folder:
            self._start_scan([folder])

    def stop_scan(self):
        if self.scanning:
            self.stop_event.set()
            self.lbl_status.configure(text="Durduruluyor...")

    def _start_scan(self, roots):
        if self.scanning:
            return
        self.scanning = True
        self.stop_event.clear()
        self.scanned_count = 0
        self.found_count = 0
        self.lbl_scanned.configure(text="Taranan: 0")
        self.lbl_found.configure(text="Tespit edilen: 0")
        self.progress.set(0)
        self.lbl_percent.configure(text="%0")
        self._clear_log()
        self.btn_scan.configure(state="disabled")
        self.btn_folder.configure(state="disabled")
        self.btn_stop.configure(state="normal")
        threading.Thread(target=self._scan_worker, args=(roots,), daemon=True).start()

    # ---------------------------- Tarama iş parçacığı ----------------------------
    def _scan_worker(self, roots):
        q = self.msg_q
        protected = protected_dirs()
        own_exe = norm(sys.executable)
        try:
            q.put(("log", "Taranacak konumlar:", "info"))
            for r in roots:
                q.put(("log", f"  • {r}", "info"))
            q.put(("status", "Dosyalar listeleniyor..."))

            entries, seen = [], set()
            for root in roots:
                if norm(root) in protected:
                    q.put(("log", f"[ATLANDI] Korumalı sistem klasörü: {root}", "info"))
                    continue
                for dirpath, dirnames, filenames in os.walk(root, onerror=lambda e: None):
                    if self.stop_event.is_set():
                        break
                    # Karantina deposunu, sistem klasörlerini ve çöp kutusunu atla
                    dirnames[:] = [
                        d for d in dirnames
                        if norm(os.path.join(dirpath, d)) != norm(QUARANTINE_DIR)
                        and norm(os.path.join(dirpath, d)) not in protected
                        and d.lower() not in SKIP_DIR_NAMES
                    ]
                    for d in dirnames:
                        p = os.path.join(dirpath, d)
                        if norm(p) not in seen:
                            seen.add(norm(p))
                            entries.append((p, True))
                    for f in filenames:
                        p = os.path.join(dirpath, f)
                        if norm(p) not in seen:
                            seen.add(norm(p))
                            entries.append((p, False))
                    if len(entries) % 2000 < len(dirnames) + len(filenames):
                        q.put(("status", f"Dosyalar listeleniyor... ({len(entries)})"))
                if self.stop_event.is_set():
                    break

            total = len(entries)
            q.put(("log", f"Toplam {total} öğe taranacak.", "info"))
            q.put(("status", "Taranıyor..."))

            quarantined_dirs = []
            scanned = found = 0
            for i, (path, is_dir) in enumerate(entries, 1):
                if self.stop_event.is_set():
                    break
                scanned = i
                # Karantinaya alınan bir klasörün içindeki öğeleri atla
                if any(is_inside(path, qd) for qd in quarantined_dirs):
                    continue
                if norm(path) == own_exe or not os.path.lexists(path):
                    continue
                # Kendi karantina deposunu / çalıştırılabilir dosyayı barındıran klasörleri koru
                if is_dir and (is_inside(QUARANTINE_DIR, path) or is_inside(sys.executable, path)):
                    continue

                threat = analyze(path, is_dir)
                if threat:
                    try:
                        quarantine_item(path, is_dir, threat)
                        found += 1
                        if is_dir:
                            quarantined_dirs.append(path)
                        kind = "KLASÖR" if is_dir else "DOSYA"
                        q.put(("log", f"[TEHDİT] {kind}: {path}  →  {threat}  |  KARANTİNAYA ALINDI",
                               "threat"))
                    except Exception as e:
                        q.put(("log", f"[HATA] Karantinaya alınamadı: {path} ({e})", "threat"))
                else:
                    q.put(("log", f"[TEMİZ] {path}", "ok"))

                if i % 10 == 0 or threat or i == total:
                    q.put(("progress", i / max(total, 1), scanned, found))

            q.put(("progress", scanned / max(total, 1) if total else 1.0, scanned, found))
            q.put(("done", scanned, found, self.stop_event.is_set()))
        except Exception as e:
            q.put(("log", f"[HATA] Tarama sırasında beklenmeyen hata: {e}", "threat"))
            q.put(("done", self.scanned_count, self.found_count, True))

    # ---------------------------- Kuyruk işleme (ana iş parçacığı) ----------------------------
    def _process_queue(self):
        lines = []
        done_msg = None
        try:
            for _ in range(500):
                msg = self.msg_q.get_nowait()
                kind = msg[0]
                if kind == "log":
                    lines.append((msg[1], msg[2]))
                elif kind == "status":
                    self.lbl_status.configure(text=msg[1])
                elif kind == "progress":
                    _, frac, scanned, found = msg
                    self.scanned_count, self.found_count = scanned, found
                    self.progress.set(min(max(frac, 0), 1))
                    self.lbl_percent.configure(text=f"%{int(frac * 100)}")
                    self.lbl_scanned.configure(text=f"Taranan: {scanned}")
                    self.lbl_found.configure(text=f"Tespit edilen: {found}")
                elif kind == "done":
                    done_msg = msg
        except queue.Empty:
            pass

        self._log_lines(lines)
        if done_msg:
            self._finish_scan(*done_msg[1:])
        self.after(80, self._process_queue)

    def _finish_scan(self, scanned, found, stopped):
        self.scanning = False
        self.btn_scan.configure(state="normal")
        self.btn_folder.configure(state="normal")
        self.btn_stop.configure(state="disabled")
        self.lbl_scanned.configure(text=f"Taranan: {scanned}")
        self.lbl_found.configure(text=f"Tespit edilen: {found}")
        if stopped:
            status = f"Tarama durduruldu. {scanned} öğe tarandı, {found} tehdit karantinaya alındı."
        else:
            self.progress.set(1)
            self.lbl_percent.configure(text="%100")
            status = f"Tarama tamamlandı. {scanned} öğe tarandı, {found} tehdit karantinaya alındı."
        self.lbl_status.configure(text=status)
        self._log_lines([(status, "good")])
        self.refresh_quarantine()
        if found and not stopped:
            messagebox.showinfo(APP_NAME, f"{found} tehdit tespit edildi ve karantinaya alındı.")

    # ---------------------------- Karantina listesi ----------------------------
    def _on_tab_change(self):
        if self.tabs.get() == "Karantina Bölümü":
            self.refresh_quarantine()

    def refresh_quarantine(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        try:
            rows = db_list()
        except Exception as e:
            messagebox.showerror(APP_NAME, f"Veritabanı okunamadı:\n{e}")
            return
        for r in rows:
            self.tree.insert("", "end", iid=str(r["id"]), values=(
                r["original_name"], r["original_path"], r["threat"] or "-",
                r["quarantine_date"], "Klasör" if r["is_dir"] else "Dosya"))
        self.lbl_qinfo.configure(text=f"Karantinadaki öğe sayısı: {len(rows)}   |   Depo: {QUARANTINE_DIR}")

    def _show_context_menu(self, event):
        row = self.tree.identify_row(event.y)
        if not row:
            return
        self.tree.selection_set(row)
        self.tree.focus(row)
        try:
            self.menu.tk_popup(event.x_root, event.y_root)
        finally:
            self.menu.grab_release()

    def _selected_record(self):
        sel = self.tree.selection()
        if not sel:
            return None
        return db_get(int(sel[0]))

    # ---------------------------- Geri yükleme / silme ----------------------------
    def restore_selected(self):
        rec = self._selected_record()
        if not rec:
            return
        if not messagebox.askyesno(
                APP_NAME,
                f"'{rec['original_name']}' zararlı olarak işaretlenmişti.\n\n"
                f"Yine de şu konuma geri yüklensin mi?\n{rec['original_path']}"):
            return

        src = os.path.join(QUARANTINE_DIR, rec["quarantine_name"])
        if not os.path.lexists(src):
            if messagebox.askyesno(APP_NAME, "Karantina dosyası bulunamadı. Kayıt listeden kaldırılsın mı?"):
                db_delete(rec["id"])
                self.refresh_quarantine()
            return

        dest = rec["original_path"]
        try:
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            if os.path.lexists(dest):  # aynı adda öğe varsa üzerine yazma
                base, ext = os.path.splitext(dest)
                dest = f"{base}_geri_yuklendi_{datetime.now().strftime('%H%M%S')}{ext}"
            shutil.move(src, dest)
            db_delete(rec["id"])
        except Exception as e:
            messagebox.showerror(APP_NAME, f"Geri yükleme başarısız:\n{e}")
            return

        self.refresh_quarantine()
        self._log_lines([(f"[GERİ YÜKLENDİ] {dest}", "info")])
        messagebox.showinfo(APP_NAME, f"Öğe geri yüklendi:\n{dest}")

    def delete_selected(self):
        rec = self._selected_record()
        if not rec:
            return
        if not messagebox.askyesno(APP_NAME, f"'{rec['original_name']}' kalıcı olarak silinsin mi?\n"
                                             "Bu işlem geri alınamaz."):
            return
        target = os.path.join(QUARANTINE_DIR, rec["quarantine_name"])
        try:
            if os.path.isdir(target) and not os.path.islink(target):
                shutil.rmtree(target)
            elif os.path.lexists(target):
                os.remove(target)
            db_delete(rec["id"])
        except Exception as e:
            messagebox.showerror(APP_NAME, f"Silme başarısız:\n{e}")
            return
        self.refresh_quarantine()

    def _on_close(self):
        self.stop_event.set()
        self.destroy()


if __name__ == "__main__":
    db_init()
    app = AnkaSecurityApp()
    app.mainloop()
